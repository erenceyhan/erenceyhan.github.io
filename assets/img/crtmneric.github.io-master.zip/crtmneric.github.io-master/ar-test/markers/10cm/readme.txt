All images in this directory are 10cm by 10cm.
